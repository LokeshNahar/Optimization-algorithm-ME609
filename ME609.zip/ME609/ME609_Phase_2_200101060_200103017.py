
# from ME609_Phase_1_200101060_200103017 import bounding_phase_method, interval_halving_method
import math 
import random
import numpy as np


def objective_function(x, question_no):
    n = len(x)
    ans = 0
    match question_no:
        case 1:
            print("Sum Squares Function: ")
            for i in range (n):
                ans += (i+1) * pow(x[i],2)
        case 2:
            print("Rosenbrock Function: ")
            for i in range(n - 1):
                term1 = 100 * (x[i + 1] - x[i]**2)**2
                term2 = (1 - x[i])**2
                ans += term1 + term2
        case 3:
            print("Dixons price Function: ")
            ans = (x[0] - 1)**2
            for i in range(2, n + 1):
                ans += i * (2 * x[i - 1]**2 - x[i - 2])**2

        case 4:
            print("Trid Function: ")

            ans = sum((x[i] - 1)**2 for i in range(n)) - sum(x[i] * x[i-1] for i in range(1, n))

        case 5:
            print("Zakharov Function: ")

            term1 = sum(x[i]**2 for i in range(n))
            term2 = sum(0.5 * (i + 1) * x[i] for i in range(n))
            term3 = term2**2
            term4 = term2**4
            ans = term1 + term3 + term4

        case 6:
            return (pow((x[0]**2 + x[1] -11),2)+pow((x[0]+x[1]**2-7),2))
    print(ans)
    return ans


def calculate_distance(point1, point2):
    # Ensure the points are NumPy arrays for element-wise operations
    point1 = np.array(point1)
    point2 = np.array(point2)

    # Calculate the squared differences between corresponding coordinates
    squared_diff = (point2 - point1)**2

    # Sum the squared differences and take the square root
    distance = np.sqrt(np.sum(squared_diff))

    return distance


#Interval Halving method
def interval_halving_method(a, b, e,question_no,epsilon = 1e-4):
    
    print("*********************************************")
    print("Interval Halving Method")
    # epsilon = float(input("Enter the epsilon value(by default 10^-3): "))
    #value of xm
    x_m = (a+b)/2
    #length
    l = calculate_distance(a,b)
    #f(xm) function evaluation
    f_x_m = objective_function(x_m,question_no)
    #counter for function evaluations
    f_eval = 1
    #counter for num_iterations
    iter = 1
    #create a file according to the question/function number

    # out.write(str(iter)+"\t\t"+str(round(a,4))+"\t\t"+"nil"+"\t\t"+"nil"+"\t\t"+str(round(b,4))+"\t\t"+str(round(x_m,4))+"\t\t"+"nil"+"\t\t"+"nil"+"\t\t"+str(round(f_x_m,4)))
    #if |l|<epsilon   we break
    while(abs(l)>= epsilon):

        #step 2
        x_1 = a+(l/4)*e
        x_2 = b-(l/4)*e
        f_x_1 = objective_function(x_1,question_no)
        f_x_2 = objective_function(x_2,question_no)
        f_eval+=2
        #2 more evaluations for each iterations
        #step 3
        if(f_x_1 < f_x_m):
            b= x_m
            x_m = x_1
            f_x_m = f_x_1
        elif(f_x_2 < f_x_m):
            a=x_m
            x_m = x_2
            f_x_m  = f_x_2
        else:
            a=x_1
            b=x_2
        #step 4 new length
        l = calculate_distance(a,b)

        iter+=1
        #writting to the log file
        # out.write(str(iter)+"\t\t"+str(round(a,4))+"\t\t"+str(round(x_1,4))+"\t\t"+str(round(x_2,4))+"\t\t"+str(round(b,4))+"\t\t"+str(round(x_m,4))+"\t\t"+str(round(f_x_1,4))+"\t\t"+str(round(f_x_2,4))+"\t\t"+str(round(f_x_m,4)))


    print("*********************************************")
    return a,b





def bounding_phase_method(current,e,i,question_no,delta = 0.02):
    k = 0
    n = len(current)
    #step 1 set k = 0 , choose initial guess
    print("*********************************************")
    print("Bounding Phase Method")
    x_0 = np.array([0])
    while(1):
        # x_0 = float(input("Enter initial guess: "))
        x_0 = np.array([random.randint(int(-1e7), int(1e7)+1) for _ in range(n)])
        f_x_0 = objective_function(x_0,question_no)
        f_x_0_del_minus = objective_function((x_0-delta*e),question_no)
        f_x_0_del_plus = objective_function((x_0+delta*e),question_no)
        if(f_x_0_del_minus<=f_x_0<=f_x_0_del_plus):
            delta = -delta
            break
        elif(f_x_0_del_minus>=f_x_0>=f_x_0_del_plus):
            break
        else:
            print("Choose some other initial guess: ")



    x_k =x_k_minus_1 = x_0
    x_k_plus_1 = x_k + ((2**k)*(delta)) * e
    f_x_k_plus_1 = objective_function(x_k_plus_1,question_no)
    f_x_k = objective_function(x_k,question_no)


    f_eval = 2
    iter = 1

    

    while(f_x_k_plus_1<f_x_k):
        k+=1
        iter +=1
        x_k_minus_1 = x_k
        x_k = x_k_plus_1
        x_k_plus_1 = x_k + ((2**k)*(delta))*e
        f_x_k  = f_x_k_plus_1
        f_x_k_plus_1 = objective_function(x_k_plus_1,question_no)
        # out.write(str(iter)+"\t\t"+str(round(x_k_minus_1,4))+"\t\t"+str(round(x_k,4))+"\t\t"+str(round(x_k_plus_1,4))+"\t\t"+str(round(f_x_k,4))+"\t\t"+str(round(f_x_k_plus_1,4)))

        f_eval+=1

    if(x_k_minus_1[i] == min(x_k_minus_1[i],x_k_plus_1[i])):
        return x_k_minus_1, x_k_plus_1
    else:
        return x_k_plus_1,x_k_minus_1


    




def helper_function( current,e,i, question_no):
    a,b = bounding_phase_method(current,e,i,question_no)
    a,b = interval_halving_method(a,b,e,question_no)
    return (a+b)/2



# Powell's Conjugate Direction Method
def powells_conjugate_direction( starting_position, question_no, epsilon=1e-4,max_iterations = 100):
    n = len(starting_position)
    # e = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    # directions=np.array(e)
    directions = np.eye(n)

    x= starting_position
    x1 = starting_position + 2 * 10
    num_iterations = 0  
    #termination Condition
    while np.max(np.abs(x - x1)) > epsilon:
        num_iterations += 1
        current = x
        #first n searches for s1 s2 .... upto sn
        for i in range(n):
            theta = helper_function( current,directions[:, i],i,question_no)
            current = current + theta * directions[:, i]
        #new directions
        for i in range(n - 1):
            directions[:, i] = directions[:, i + 1]
        directions[:, n - 1] = current - x
        #last search along s1 which is now curr - x      (d)
        x1 = x
        theta = helper_function(current,directions[:, n-1],n-1, question_no)
        x = current + theta * directions[:, n - 1]
        #if number pf iterations exceed
        if(num_iterations > max_iterations):
            break

    fx = objective_function(x,question_no)

    return x, fx, num_iterations
#






# def conjugate_direction(ls,max_iter = 200):
#     n = len(ls)
#     e = [[0 for _ in range(n)] for _ in range(n)]
#     for i in range(n):
#         e[i][i] = 1
#     iter =0
#     x_0 = ls.copy()
#     while(iter<max_iter):
#         x_old = x.copy()
#         for i in range(n):
#             # Perform line search in the direction of the basis vectors
#             direction = e[i]
#             alpha = line_search(obj_func, x, direction)
#             x = x + alpha * direction

#         # Update e
#         for i in range(1, n):
#             e[i] = e[i - 1]

    



def main_program():
    question_no = int(input("Enter question number: "))

    n = int(input("Enter number of variables: "))
    
    ls =[]
    for _ in range(n):
        k = int(input())
        ls.append(k)
    x = np.array(ls)
    # e =np.array([1,0])
    # result = powells_conjugate_direction(x, question_no)
    # print("Optimal solution:", result)
    # print(objective_function(x,question_no))
    # a,b = bounding_phase_method(x,e,question_no)
    # a,b = interval_halving_method(a,b,question_no)
    print(powells_conjugate_direction(x,question_no))
    # print(a,b)

if __name__ == "__main__":
    main_program()