

import numpy as np
from functions import *
from math import *
# from interface import *
import random




def bounding_phase_method(function,current,a,b, e,i, delta = 0.02):
    k = 0
    n = len(current)
    #step 1 set k = 0 , choose initial guess
    x_0 = np.array([(a+b)/2])
    while(1):
        # x_0 = float(input("Enter initial guess: "))
        x_0 = np.array([random.randint(int(a), int(b)+1) for _ in range(n)])
        f_x_0 = function(x_0)
        f_x_0_del_minus = function((x_0-delta*e))
        f_x_0_del_plus = function((x_0+delta *e))
        if(f_x_0_del_minus<=f_x_0<=f_x_0_del_plus):
            delta = -delta
            break
        elif(f_x_0_del_minus>=f_x_0>=f_x_0_del_plus):
            break
        else:
            print("Choose some other initial guess: ")
            x_0 = np.array([random.randint(int(a), int(b)+1) for _ in range(n)])
            break




    x_k =x_k_minus_1 = x_0
    x_k_plus_1 = x_k + ((2**k)*(delta))*e
    f_x_k_plus_1 = function(x_k_plus_1)
    f_x_k = function(x_k)


    f_eval = 2
    iter = 1
 

    while(f_x_k_plus_1<f_x_k):
        k+=1
        iter +=1
        x_k_minus_1 = x_k
        x_k = x_k_plus_1
        x_k_plus_1 = x_k + ((2**k)*(delta))*e
        f_x_k  = f_x_k_plus_1
        f_x_k_plus_1 = function(x_k_plus_1)


        f_eval+=1

    if(x_k_minus_1[i] == min(x_k_minus_1[i],x_k_plus_1[i])):
        return x_k_minus_1, x_k_plus_1
    else:
        return x_k_plus_1,x_k_minus_1




def calculate_distance(point1, point2):
    # Ensure the points are NumPy arrays for element-wise operations
    point1 = np.array(point1)
    point2 = np.array(point2)

    # Calculate the squared differences between corresponding coordinates
    squared_diff = (point2 - point1)**2

    # Sum the squared differences and take the square root
    distance = np.sqrt(np.sum(squared_diff))

    return distance


#Interval Halving method
def interval_halving(function,a, b, e,epsilon = 1e-4):
    
    print("*********************************************")
    print("Interval Halving Method")
    # epsilon = float(input("Enter the epsilon value(by default 10^-3): "))
    #value of xm
    x_m = (a+b)/2
    #length
    l = calculate_distance(a,b)
    #f(xm) function evaluation
    f_x_m = function(x_m)
    #counter for function evaluations
    f_eval = 1
    #counter for num_iterations
    iter = 1
    #create a file according to the question/function number
    
    # out.write(str(iter)+"\t\t"+str(round(a,4))+"\t\t"+"nil"+"\t\t"+"nil"+"\t\t"+str(round(b,4))+"\t\t"+str(round(x_m,4))+"\t\t"+"nil"+"\t\t"+"nil"+"\t\t"+str(round(f_x_m,4)))
    #if |l|<epsilon   we break
    while(abs(l)>= epsilon):

        #step 2
        x_1 = a+((l/4)*e)
        x_2 = b-((l/4)*e)
        f_x_1 = function(x_1)
        f_x_2 = function(x_2)
        f_eval+=2
        #2 more evaluations for each iterations
        #step 3
        if(f_x_1 < f_x_m):
            b= x_m
            x_m = x_1
            f_x_m = f_x_1
        elif(f_x_2 < f_x_m):
            a=x_m
            x_m = x_2
            f_x_m  = f_x_2
        else:
            a=x_1
            b=x_2
        #step 4 new length
        l = calculate_distance(a,b)

        iter+=1
        #writting to the log file
        # out.write(str(iter)+"\t\t"+str(round(a,4))+"\t\t"+str(round(x_1,4))+"\t\t"+str(round(x_2,4))+"\t\t"+str(round(b,4))+"\t\t"+str(round(x_m,4))+"\t\t"+str(round(f_x_1,4))+"\t\t"+str(round(f_x_2,4))+"\t\t"+str(round(f_x_m,4)))
    return a,b


def inter(function, e, current, a, b, tolerance):
    xm = (a+b)/2


# def new_fn(function, e, current, a, b, tolerance):
#     c = (3 - sqrt(5)) / 2
#     x1 = a + (b - a) * c
#     x2 = a + b - x1

#     fx1 = function(current + x1 * e)
#     fx2 = function(current + x2 * e)

#     while b - a > tolerance:
#         if fx1 <= fx2:
#             b = x2
#             x2 = x1
#             fx2 = fx1
#             x1 = a + c * (b - a)
#             fx1 = function(current + x1 * e)
#             x = x1
#         else:
#             a = x1
#             x1 = x2
#             fx1 = fx2
#             x2 = b - c * (b - a)
#             fx2 = function(current + x2 * e)
#             x = x2

#     return x


def helper_function(function, e, i, current, tolerance ):
    a, b = bounding_phase_method(function,current, 1e-7,1e6,e,i)
    a,b = interval_halving(function,a , b, e )
    return (a+b)/2



def powell(function, helper_function, starting_position, tolerance):
    dimension = starting_position.size
    e = np.eye(dimension)
    x = starting_position
    x1 = starting_position + 2 * 10
    num_iterations = 0

    while np.max(np.abs(x - x1)) > tolerance:
        num_iterations += 1
        current = x
        for i in range(dimension):
            theta = helper_function(function, e[:, i], i,current,  tolerance)
            current = current + theta * e[:, i]

        for i in range(dimension - 1):
            e[:, i] = e[:, i + 1]
        e[:, dimension - 1] = current - x

        x1 = x
        theta = helper_function(function, e[:, dimension - 1], dimension-1,current, tolerance)
        x = current + theta * e[:, dimension - 1]


    fx = function(x)

    return x, fx, num_iterations



if __name__ == '__main__':
    # Testni slucajevi:

    a = np.array([1.0, 4.0]).T
    b = np.array([2, 1, 2, 1, 3, 2, -1, 0, 1, 2]).T
    c = np.array([2, 2, 2, 3]).T
    d = np.array([-1.2, 1]).T

    
    print(powell(sum_squares, helper_function, b, 0.0001))
    
