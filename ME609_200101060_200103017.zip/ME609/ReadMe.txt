ReadMe:

Author:
Lokesh Nahar 200101060
Arnav Singh 2001013017


To run the Phase 3 code open the folder in the terminal, and run the following code:
python3 ME609_Phase_3_200101060_200103017.py


it will take input_.txt as the input file, whose first line contains the question number, secondline contains the number of variable, the next n line contains the initial starting point, followed by n lines of upper bound and the next n line of lower bound for the values of x vector.

for simplicity we have pprepared the input files for question 1,2 and 3
to run 1st question change the file name to input.txt and so on...


the output will be stored in Powell_Conjugate_direction_output_(question_no).txt


"Optimization is the art of finding the best way to achieve a goal; it's a journey of continuous improvement, where efficiency and effectiveness are the guiding stars on the path to excellence"